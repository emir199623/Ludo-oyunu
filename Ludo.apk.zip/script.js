let isMicOpen = false;
let localStream;

// Mikrofonu Kontrol Et
async function toggleMic() {
    if (!localStream) {
        try {
            localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            isMicOpen = true;
            updateMicUI(0, true); // Senin koltuğun (0) mikrofonu açıldı
        } catch (err) {
            alert("Mikrofon izni reddedildi!");
        }
    } else {
        isMicOpen = !isMicOpen;
        localStream.getAudioTracks()[0].enabled = isMicOpen;
        updateMicUI(0, isMicOpen);
    }
}

function updateMicUI(seatId, status) {
    const seat = document.getElementById(`seat-${seatId}`);
    const micIcon = seat.querySelector('.mic-status');
    const btn = document.getElementById('mic-btn');
    
    if (status) {
        micIcon.innerText = "🎤";
        micIcon.style.color = "#2ecc71";
        btn.innerText = "Mikrofonu Kapat";
    } else {
        micIcon.innerText = "🔇";
        micIcon.style.color = "#e74c3c";
        btn.innerText = "Mikrofonu Aç";
    }
}

// Zar Atma ve Sıra Takibi
let currentPlayer = 0;
function rollDice() {
    let dice = Math.floor(Math.random() * 6) + 1;
    alert(`Oyuncu ${currentPlayer + 1} zar attı: ${dice}`);
    
    // Sırayı bir sonrakine geçir
    currentPlayer = (currentPlayer + 1) % 4;
    // Görsel olarak aktif oyuncuyu vurgula
    document.querySelectorAll('.seat').forEach(s => s.style.border = "none");
    document.getElementById(`seat-${currentPlayer}`).style.border = "2px solid white";
}
// Admin Mesaj Duyurusu
function sendNotice() {
    const msg = document.getElementById('admin-msg').value;
    if(msg) {
        alert("📢 SİSTEM DUYURUSU: " + msg);
        // Burada tüm oyuncuların ekranında yazı çıkmasını sağlayabiliriz
    }
}

// Seçili Oyuncuya 6 Attırma (Admin Hilesi/Yardımı)
function giveDice() {
    const selectedPlayer = document.getElementById('player-select').value;
    alert("Admin, " + (parseInt(selectedPlayer)+1) + ". oyuncuya 6 zar gönderdi!");
    // Zar fonksiyonunu tetikle ve değeri 6 yap
}

// Oyunu Duraklatma
let isPaused = false;
function adminPause() {
    isPaused = !isPaused;
    if(isPaused) {
        alert("Oyun Admin tarafından DURDURULDU!");
    } else {
        alert("Oyun Devam Ediyor...");
    }
}

// Oyuncuyu Atma
function kickPlayer() {
    const selectedPlayer = document.getElementById('player-select').value;
    const seat = document.getElementById(`seat-${selectedPlayer}`);
    seat.style.opacity = "0.3";
    seat.querySelector('.name').innerText = "ATILDI";
}
const SECRET_PASSWORD = "Alisa3636";

function openAdminLogin() {
    document.getElementById('admin-login-screen').style.display = 'flex';
}

function closeLogin() {
    document.getElementById('admin-login-screen').style.display = 'none';
}

function checkAdminPassword() {
    const input = document.getElementById('admin-password-input').value;
    
    if (input === SECRET_PASSWORD) {
        alert("Hoş geldin Admin Alisa! Yetkiler tanımlandı.");
        document.getElementById('admin-login-screen').style.display = 'none';
        document.getElementById('admin-panel').style.display = 'block'; // Paneli göster
        
        // Admin olduğun belli olsun diye arka planı hafifçe değiştir
        document.getElementById('background-layer').style.background = "linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d)";
    } else {
        alert("Hatalı Şifre! Yetkisiz Erişim.");
        document.getElementById('admin-password-input').value = "";
    }
}
// Admin Paneline yeni bir özellik: Herkesin sesini kapatma (Susturma)
function adminMuteAll() {
    alert("Admin tüm mikrofonları susturdu!");
    // Tüm uzak stream'lerin sesini 0 yapma mantığı buraya gelir
}

// Oyunu sıfırla (Admin yetkisiyle)
function adminResetGame() {
    if(confirm("Tüm oyunu sıfırlamak istediğine emin misin?")) {
        location.reload(); 
    }
}
